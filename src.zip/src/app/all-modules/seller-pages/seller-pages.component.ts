import { Component } from '@angular/core';

@Component({
  selector: 'app-seller-pages',
  templateUrl: './seller-pages.component.html',
  styleUrls: ['./seller-pages.component.css']
})
export class SellerPagesComponent {

}
