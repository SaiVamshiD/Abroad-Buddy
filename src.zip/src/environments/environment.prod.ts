export const environment = {
  production: true,
  appUrl :"http://localhost:4200",
  baseUrl:"http://dairysystem.in/Buddy/admin",   
};
