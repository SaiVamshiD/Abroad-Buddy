import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ChatingRoutingModule } from './chating-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    ChatingRoutingModule
  ]
})
export class ChatingModule { }
